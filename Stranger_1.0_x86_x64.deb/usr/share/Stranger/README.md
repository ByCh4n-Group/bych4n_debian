#                                 Stranger

**Contact:**
[*Discord*](https://discord.gg/pnmP8NHphr)
[*YouTube*](https://www.youtube.com/channel/UCdi2xN2EYCRR3PSGEy7HHvw)


![logo](https://cdn.discordapp.com/attachments/742135407583559690/817698143134941185/MOSHED-2021-3-6-10-0-7.gif)

## Downloand&Usage

```bash
git clone https://github.com/RiseToDev751/Stranger
cd Stranger
chmod +x setup.sh
sudo bash setup.sh
python3 main.py
```
Installation Will Be Made If Required Components Are Missing.
Run the main.py file without putting sudo.

## Thanks By

Nick Name | Github Link
--- | --- 
**RiseToDev751** | [*RiseToDev751*](https://github.com/RiseToDev751)
**ByCh4n**  | [*ByCh4n*](https://github.com/ByCh4n/)
**lazypwny** | [*lazypwny751*](https://github.com/lazypwny751)

## Photos From Tool

![1](https://cdn.discordapp.com/attachments/742135407583559690/817500311764729866/unknown.png)

## License
[GPL-3.0](https://choosealicense.com/licenses/gpl-3.0/)

