[![forthebadge](https://forthebadge.com/images/badges/made-with-python.svg)](https://forthebadge.com)

![baycan (1)](https://cdn.discordapp.com/attachments/742135407583559690/797730720234602496/markdown.png)

TR
--
Bu Program RiseToDev Tarafından Hazırlanmıştır.

Instagram 📸 : risetodev_ahmet

Dosyalarınızdaki Yetkilendirmeleri Daha Kısa Zaman İçerisinde Yapabileceksiniz. 💯

Kullanımı Çok Basit Python Üzerine Yazılmış Bir Programdır. 💯

EN
--
This Program Has Been Prepared By RiseToDev.

Instagram 📸: risetodev_ahmet

You will be able to manage the permissions on your files in a shorter time. 💯

It Is Very Simple To Use And A Program Written On Python. 💯

--------------------------------------------------------------------------

Linux - Installation(Kurulum):
--
- git clone https://github.com/ByCh4n-Group/ChmodCalculator

- cd ChmodCalculator

- pip3 install -r requirements.txt

- python3 main.py

--------------------------------------------------------------------------

- Dilerim Ki Sizler İçin Yararlı Olmuştur. :)

- I think it's been good for you. :)

- Linux ✔


![1](https://cdn.discordapp.com/attachments/742135407583559690/798202068967227442/gui2.PNG)

![2](https://cdn.discordapp.com/attachments/742135407583559690/798202072079925258/gui3.PNG)
